package com.bnpparibas.ism.processmgt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProcessmgtApplicationTests {

	@Test
	void contextLoads() {
	}

}
