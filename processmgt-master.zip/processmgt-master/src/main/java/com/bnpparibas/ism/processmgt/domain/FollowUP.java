package com.bnpparibas.ism.processmgt.domain;

public enum FollowUP {
    STANDARD,
    LIGHT,
    ENFORCED;
}
