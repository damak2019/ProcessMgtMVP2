package com.bnpparibas.ism.processmgt.domain.exception;

public final class ErrorCodes {
    private ErrorCodes() {}

    public static final String METHOD_NOT_FOUND = "ERR_0001";
}
