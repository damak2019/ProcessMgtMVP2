import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-process-searsh-form',
  templateUrl: './process-searsh-form.component.html',
  styleUrls: ['./process-searsh-form.component.css']
})
export class ProcessSearshFormComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
