import { MappingMethodDTO } from './mapping-method-dto';

describe('MappingMethodDTO', () => {
  it('should create an instance', () => {
    expect(new MappingMethodDTO()).toBeTruthy();
  });
});
