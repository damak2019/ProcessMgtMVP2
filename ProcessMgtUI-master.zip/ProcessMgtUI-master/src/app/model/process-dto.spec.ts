import { ProcessDTO } from './process-dto';

describe('ProcessDTO', () => {
  it('should create an instance', () => {
    expect(new ProcessDTO()).toBeTruthy();
  });
});
